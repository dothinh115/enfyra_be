export const HIDDEN_FIELD_KEY = 'hidden_field';
export const GLOBAL_ROUTES_KEY = 'global-routes';
export const RELOADING_DATASOURCE_KEY = 'reloading-data-source';
export const IS_PUBLIC_KEY = 'isPublic';
