import { AutoService } from '../auto/auto.service';
import { TableDefinition } from '../entities/table.entity';
import {
  CreateColumnDto,
  CreateRelationDto,
  CreateTableDto,
} from '../table/dto/create-table.dto';
import { BadRequestException, Injectable, Logger } from '@nestjs/common';
import { DataSourceService } from '../data-source/data-source.service';

@Injectable()
export class TableHanlderService {
  constructor(
    private dataSouceService: DataSourceService,
    private autoService: AutoService,
  ) {}

  async createTable(body: CreateTableDto) {
    const queryRunner = this.dataSouceService
      .getDataSource()
      .createQueryRunner();
    await queryRunner.connect(); // Kết nối
    await queryRunner.startTransaction();
    const manager = queryRunner.manager;
    try {
      const hasTable = await queryRunner.hasTable(body.name);
      let result = await manager.findOne(TableDefinition, {
        where: {
          name: body.name,
        },
      });
      if (hasTable && result) {
        throw new BadRequestException(`Bảng ${body.name} đã tồn tại!`);
      }

      // Tạo entity từ dữ liệu đã được xử lý
      const tableEntity = manager.create(TableDefinition, {
        name: body.name,
        columns: this.normalizeColumnsWithAutoId(body.columns),
        relations: body.relations ? this.prepareRelations(body.relations) : [],
      } as any);

      if (!result) result = await manager.save(TableDefinition, tableEntity);
      await queryRunner.commitTransaction();
      await this.autoService.pullMetadataFromDb();

      return result;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      console.error(error.stack || error.message || error);
      throw new BadRequestException(error.message || 'Unknown error');
    } finally {
      await queryRunner.release();
    }
  }

  async updateTable(id: number, body: CreateTableDto) {
    const queryRunner = this.dataSouceService
      .getDataSource()
      .createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();
    const manager = queryRunner.manager;
    try {
      const exists = await manager.findOne(TableDefinition, {
        where: {
          id,
        },
        relations: ['columns', 'relations'],
      });
      if (!exists) {
        throw new BadRequestException(`Table ${body.name} không tồn tại.`);
      }

      const oldColumn = exists.columns;
      const newColumn = body.columns.filter((col) => col.id);
      for (const newCol of newColumn) {
        const oldCol = oldColumn.find((col) => col.id === newCol.id);

        if (!oldCol) {
          console.warn(
            `⚠️ Không tìm thấy column với id = ${newCol.id}, bỏ qua.`,
          );
          continue;
        }
        if (newCol.name !== oldCol.name) {
          await queryRunner.query(
            `ALTER TABLE \`${exists.name}\` RENAME COLUMN \`${oldCol.name}\` TO \`${newCol.name}\`;`,
          );
        }
      }

      // Tạo entity từ dữ liệu đã được xử lý
      const tableEntity = manager.create(TableDefinition, {
        id: body.id,
        ...body,
        columns: this.normalizeColumnsWithAutoId(body.columns),
        relations: body.relations ? this.prepareRelations(body.relations) : [],
      });
      const result = await manager.save(TableDefinition, tableEntity);

      await queryRunner.commitTransaction();
      await this.autoService.pullMetadataFromDb();

      return result;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      console.error(error.stack || error.message || error);
      throw new BadRequestException(error.message || 'Unknown error');
    } finally {
      await queryRunner.release();
    }
  }

  prepareRelations(relationsDto: CreateRelationDto[] = []) {
    const result = relationsDto.map((relation) => ({
      ...relation,
      targetTable: { id: relation.targetTable },
    }));
    return result;
  }

  normalizeColumnsWithAutoId(columns: CreateColumnDto[]): CreateColumnDto[] {
    // Tìm xem user có cố gắng định nghĩa cột id không
    const userIdCol = columns.find((col) => col.name === 'id');
    const idType = userIdCol?.type === 'varchar' ? 'uuid' : 'int';

    // Loại bỏ cột id do user định nghĩa
    const filtered = columns.filter((col) => col.name !== 'id');

    // Tạo cột id chuẩn
    const idColumn: CreateColumnDto =
      idType === 'uuid'
        ? {
            name: 'id',
            type: 'varchar',
            isPrimary: true,
            isGenerated: true,
            isNullable: false,
          }
        : {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            isNullable: false,
          };

    // Trả về kết quả
    return [idColumn, ...filtered];
  }

  async find() {
    try {
      const repo = this.dataSouceService.getRepository(TableDefinition);
      return await repo.find();
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async findOne(id: number) {
    try {
      const repo = this.dataSouceService.getRepository(TableDefinition);
      return await repo.findOne({
        where: { id },
      });
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async delete(id: number) {
    const repo = this.dataSouceService.getRepository(TableDefinition);

    try {
      const exists = await repo.findOne({
        where: {
          id,
        },
      });
      console.log(exists);
      if (!exists) {
        throw new BadRequestException(`Table với id ${id} không tồn tại.`);
      }

      const result = await repo.remove(exists);

      await this.autoService.pullMetadataFromDb();
      return result;
    } catch (error) {
      console.error(error.stack || error.message || error);
      throw new BadRequestException(error.message || 'Unknown error');
    }
  }
}
