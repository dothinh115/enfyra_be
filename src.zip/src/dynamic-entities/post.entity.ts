import { Entity, Column, PrimaryGeneratedColumn, ManyToMany, JoinTable, CreateDateColumn, UpdateDateColumn } from "typeorm";
import { Category } from "./category.entity";

@Entity("post")
export class Post {
  @Column({type:'varchar', nullable: false, default: null})
  title: string;

  @PrimaryGeneratedColumn('increment')
  id: number;

  @ManyToMany(() => Category, { nullable: true})
  @JoinTable()
  categories: Category[];

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  UpdatedAt: Date;
}