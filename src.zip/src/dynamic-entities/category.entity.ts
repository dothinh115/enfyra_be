import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn } from "typeorm";

@Entity("category")
export class Category {
  @Column({type:'varchar', nullable: false, default: null})
  name: string;

  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({type:'varchar', nullable: true, default: null})
  test: string;


  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  UpdatedAt: Date;
}